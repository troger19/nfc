import FastImage from 'react-native-fast-image';
export default FastImage;
